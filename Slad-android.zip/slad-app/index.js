// Najpierw rejestrujemy zadanie śledzenia w tle, dopiero potem aplikację.
import './src/tracking';
import { registerRootComponent } from 'expo';
import App from './App';

registerRootComponent(App);
