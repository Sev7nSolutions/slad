import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AppState, Linking, StatusBar, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { WebView } from 'react-native-webview';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Location from 'expo-location';
import * as SplashScreen from 'expo-splash-screen';

import MAP_HTML from './src/mapHtml';
import LoadingScreen from './src/LoadingScreen';
import { drainBuffer, isTracking, setListener, startTracking, stopTracking } from './src/tracking';

const STORE_KEYS = ['slad.routes.v1', 'slad.live.v1', 'slad.pins.v1'];
const MIN_LOADING_MS = 1600;

SplashScreen.preventAutoHideAsync().catch(() => {});

export default function App() {
  const web = useRef(null);
  const watchRef = useRef(null);
  const fgRecord = useRef(false); // nagrywanie z podglądu pozycji, gdy tło niedostępne
  const [init, setInit] = useState(null);
  const [mapReady, setMapReady] = useState(false);
  const [minTimePassed, setMinTimePassed] = useState(false);
  const [showLoader, setShowLoader] = useState(true);

  // systemowy splash (to samo logo na białym) -> płynnie przechodzi w nasz ekran ładowania
  useEffect(() => {
    SplashScreen.hideAsync().catch(() => {});
    const t = setTimeout(() => setMinTimePassed(true), MIN_LOADING_MS);
    const fallback = setTimeout(() => setMapReady(true), 8000); // np. brak internetu
    return () => { clearTimeout(t); clearTimeout(fallback); };
  }, []);

  // 1) wczytaj zapisane trasy zanim pokażemy mapę
  useEffect(() => {
    (async () => {
      const data = {};
      for (const k of STORE_KEYS) {
        try {
          const v = await AsyncStorage.getItem(k);
          if (v) data[k] = JSON.parse(v);
        } catch {}
      }
      setInit(data);
    })();
  }, []);

  const post = useCallback((msg) => {
    web.current?.injectJavaScript(`window.onNative && window.onNative(${JSON.stringify(msg)}); true;`);
  }, []);

  // punkty zebrane w tle -> mapa
  const flush = useCallback(async () => {
    const pts = await drainBuffer();
    if (pts.length) post({ type: 'loc', points: pts });
  }, [post]);

  // podgląd pozycji (niebieska kropka), kiedy apka jest na ekranie
  const startWatch = useCallback(async () => {
    if (watchRef.current) return;
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      post({ type: 'perm', reason: 'fg' });
      return;
    }
    watchRef.current = await Location.watchPositionAsync(
      { accuracy: Location.Accuracy.High, timeInterval: 2000, distanceInterval: 2 },
      (l) =>
        post({
          type: 'loc',
          points: [{ lat: l.coords.latitude, lng: l.coords.longitude, acc: l.coords.accuracy, speed: l.coords.speed, t: l.timestamp, rec: fgRecord.current }],
        })
    );
  }, [post]);

  const stopWatch = useCallback(() => {
    watchRef.current?.remove();
    watchRef.current = null;
  }, []);

  useEffect(() => {
    setListener(() => {
      if (AppState.currentState === 'active') flush();
    });
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active') {
        flush();
        startWatch();
      } else {
        stopWatch(); // nagrywanie w tle działa dalej osobno
      }
    });
    return () => {
      sub.remove();
      setListener(null);
      stopWatch();
    };
  }, [flush, startWatch, stopWatch]);

  const onMessage = useCallback(
    async (e) => {
      let m;
      try {
        m = JSON.parse(e.nativeEvent.data);
      } catch {
        return;
      }
      switch (m.type) {
        case 'ready':
          setMapReady(true);
          post({ type: 'tracking', active: await isTracking() });
          await flush();
          startWatch();
          break;
        case 'store':
          if (m.value == null) AsyncStorage.removeItem(m.key);
          else AsyncStorage.setItem(m.key, JSON.stringify(m.value));
          break;
        case 'track:start': {
          try {
            const r = await startTracking();
            if (!r.ok) post({ type: 'perm', reason: r.reason });
            else {
              fgRecord.current = !r.background;
              if (!r.background) startWatch();
              post({ type: 'trackmode', background: r.background, error: r.error || null });
            }
          } catch (err) {
            fgRecord.current = true;
            startWatch();
            post({ type: 'trackmode', background: false, error: String((err && err.message) || err) });
          }
          break;
        }
        case 'track:stop':
          fgRecord.current = false;
          await stopTracking();
          await flush();
          break;
        case 'locate':
          startWatch();
          break;
        case 'openUrl':
          if (typeof m.url === 'string' && m.url.startsWith('https://')) Linking.openURL(m.url).catch(() => {});
          break;
        case 'openSettings':
          Linking.openSettings();
          break;
      }
    },
    [flush, post, startWatch]
  );

  const loading = !(init && mapReady && minTimePassed);

  return (
    <SafeAreaProvider>
      <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }} edges={['top', 'bottom']}>
        <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
        {!init ? <View style={{ flex: 1 }} /> : (
        <WebView
          ref={web}
          source={{ html: MAP_HTML, baseUrl: 'https://slad.app/' }}
          originWhitelist={['*']}
          injectedJavaScriptBeforeContentLoaded={`window.__INIT__ = ${JSON.stringify(init)}; true;`}
          onMessage={onMessage}
          javaScriptEnabled
          domStorageEnabled
          setSupportMultipleWindows={false}
          overScrollMode="never"
          androidLayerType="hardware"
          cacheEnabled
          style={{ flex: 1 }}
        />
        )}
        {showLoader && <LoadingScreen visible={loading} onHidden={() => setShowLoader(false)} />}
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
