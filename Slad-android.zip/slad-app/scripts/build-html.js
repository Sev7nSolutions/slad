// Zamienia web/map.html na moduł JS (src/mapHtml.js), który ładuje aplikacja.
// Jeśli zainstalowano paczkę maplibre-gl, jej kod i style są wklejane do środka,
// żeby apka nie pobierała ~1 MB z internetu przy każdym starcie.
// Po każdej zmianie w map.html uruchom: npm run build:html
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
let html = fs.readFileSync(path.join(root, 'web', 'map.html'), 'utf8');

const dist = path.join(root, 'node_modules', 'maplibre-gl', 'dist');
const jsFile = path.join(dist, 'maplibre-gl.js');
const cssFile = path.join(dist, 'maplibre-gl.css');
const CDN_JS = '<script src="https://unpkg.com/maplibre-gl@5/dist/maplibre-gl.js"></script>';
const CDN_CSS = '<link rel="stylesheet" href="https://unpkg.com/maplibre-gl@5/dist/maplibre-gl.css">';

if (fs.existsSync(jsFile) && fs.existsSync(cssFile)) {
  // "</script" w środku kodu zamknąłby znacznik – zabezpieczamy
  const js = fs.readFileSync(jsFile, 'utf8').replace(/<\/script/gi, '<\\/script');
  const css = fs.readFileSync(cssFile, 'utf8').replace(/<\/style/gi, '<\\/style');
  if (!html.includes(CDN_JS) || !html.includes(CDN_CSS)) throw new Error('Nie znaleziono znaczników MapLibre w map.html');
  html = html.replace(CDN_CSS, () => `<style>${css}</style>`).replace(CDN_JS, () => `<script>${js}</script>`);
  console.log('MapLibre wbudowany w apkę (' + Math.round(js.length / 1024) + ' KB)');
} else {
  console.log('Brak node_modules/maplibre-gl – MapLibre będzie pobierany z internetu (unpkg)');
}

const out = `// PLIK GENEROWANY – edytuj web/map.html i uruchom: npm run build:html\nexport default ${JSON.stringify(html)};\n`;
fs.writeFileSync(path.join(root, 'src', 'mapHtml.js'), out);
console.log('src/mapHtml.js gotowy (' + html.length + ' znaków)');
