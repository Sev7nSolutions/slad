// Zamienia web/map.html na moduł JS (src/mapHtml.js), który ładuje aplikacja.
// Po każdej zmianie w map.html uruchom: npm run build:html
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'web', 'map.html'), 'utf8');
const out = `// PLIK GENEROWANY – edytuj web/map.html i uruchom: npm run build:html\nexport default ${JSON.stringify(html)};\n`;
fs.writeFileSync(path.join(root, 'src', 'mapHtml.js'), out);
console.log('src/mapHtml.js gotowy (' + html.length + ' znaków)');
