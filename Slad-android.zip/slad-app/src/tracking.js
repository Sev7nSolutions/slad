// Nagrywanie trasy w tle (działa przy zablokowanym ekranie).
// Android pokazuje wtedy stałe powiadomienie "Ślad nagrywa trasę".
import * as TaskManager from 'expo-task-manager';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const TRACK_TASK = 'slad-background-tracking';
const BUFFER_KEY = 'slad.buffer.v1';

let listener = null;
export const setListener = (fn) => { listener = fn; };

// prosta kolejka, żeby zapis i odczyt bufora się nie nakładały
let chain = Promise.resolve();
const withLock = (fn) => {
  const run = chain.then(fn, fn);
  chain = run.catch(() => {});
  return run;
};

const toPoint = (l) => ({
  lat: l.coords.latitude,
  lng: l.coords.longitude,
  acc: l.coords.accuracy,
  speed: l.coords.speed,
  t: l.timestamp,
  rec: true,
});

// Musi być zdefiniowane na samej górze (import w index.js), żeby działało też,
// gdy system uruchomi aplikację w tle.
TaskManager.defineTask(TRACK_TASK, async ({ data, error }) => {
  if (error || !data || !data.locations) return;
  const pts = data.locations.map(toPoint);
  await withLock(async () => {
    const raw = await AsyncStorage.getItem(BUFFER_KEY);
    const cur = raw ? JSON.parse(raw) : [];
    // limit, żeby bufor nie urósł w nieskończoność
    const next = cur.concat(pts).slice(-20000);
    await AsyncStorage.setItem(BUFFER_KEY, JSON.stringify(next));
  });
  if (listener) listener();
});

// Zabiera wszystkie punkty zebrane w tle (i czyści bufor).
export const drainBuffer = () =>
  withLock(async () => {
    const raw = await AsyncStorage.getItem(BUFFER_KEY);
    if (!raw) return [];
    await AsyncStorage.removeItem(BUFFER_KEY);
    return JSON.parse(raw);
  });

export async function isTracking() {
  try {
    return await Location.hasStartedLocationUpdatesAsync(TRACK_TASK);
  } catch {
    return false;
  }
}

export async function startTracking() {
  const fg = await Location.requestForegroundPermissionsAsync();
  if (fg.status !== 'granted') return { ok: false, reason: 'fg' };

  const bg = await Location.requestBackgroundPermissionsAsync();
  if (bg.status !== 'granted') return { ok: false, reason: 'bg' };

  if (await isTracking()) return { ok: true };

  await Location.startLocationUpdatesAsync(TRACK_TASK, {
    accuracy: Location.Accuracy.BestForNavigation,
    timeInterval: 2000,
    distanceInterval: 3,
    deferredUpdatesInterval: 0,
    pausesUpdatesAutomatically: false,
    showsBackgroundLocationIndicator: true,
    foregroundService: {
      notificationTitle: 'Ślad nagrywa trasę',
      notificationBody: 'Wężyk rysuje się za Tobą 🐍',
      notificationColor: '#ef4444',
      killServiceOnDestroy: false,
    },
  });
  return { ok: true };
}

export async function stopTracking() {
  try {
    if (await isTracking()) await Location.stopLocationUpdatesAsync(TRACK_TASK);
  } catch {}
}
