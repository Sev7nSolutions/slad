import React, { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, Text, View } from 'react-native';

// Ekran ładowania: białe tło, czarne logo, nazwa i podpis wykonawcy.
export default function LoadingScreen({ visible, onHidden }) {
  const fade = useRef(new Animated.Value(1)).current;
  const scale = useRef(new Animated.Value(0.9)).current;
  const bar = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.spring(scale, { toValue: 1, friction: 6, useNativeDriver: true }).start();
    Animated.loop(
      Animated.timing(bar, { toValue: 1, duration: 1100, easing: Easing.inOut(Easing.cubic), useNativeDriver: true })
    ).start();
  }, [bar, scale]);

  useEffect(() => {
    if (!visible) {
      Animated.timing(fade, { toValue: 0, duration: 350, useNativeDriver: true }).start(() => onHidden && onHidden());
    }
  }, [visible, fade, onHidden]);

  const translateX = bar.interpolate({ inputRange: [0, 1], outputRange: [-60, 120] });

  return (
    <Animated.View style={[StyleSheet.absoluteFill, styles.wrap, { opacity: fade }]} pointerEvents={visible ? 'auto' : 'none'}>
      <View style={styles.center}>
        <Animated.Image source={require('../assets/logo.png')} style={[styles.logo, { transform: [{ scale }] }]} />
        <Text style={styles.name}>Ślad</Text>
        <Text style={styles.tag}>Twoje trasy jak wężyk</Text>
        <View style={styles.track}>
          <Animated.View style={[styles.fill, { transform: [{ translateX }] }]} />
        </View>
      </View>
      <View style={styles.footer}>
        <Text style={styles.by}>wykonanie</Text>
        <Text style={styles.brand}>Sev7nCreators</Text>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrap: { backgroundColor: '#ffffff', zIndex: 10 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  logo: { width: 150, height: 150, marginBottom: 18 },
  name: { fontSize: 34, fontWeight: '800', color: '#000', letterSpacing: -0.5 },
  tag: { fontSize: 14, color: '#6b7280', marginTop: 4 },
  track: { width: 120, height: 4, borderRadius: 4, backgroundColor: '#eef0f2', marginTop: 28, overflow: 'hidden' },
  fill: { width: 60, height: 4, borderRadius: 4, backgroundColor: '#000' },
  footer: { alignItems: 'center', paddingBottom: 28 },
  by: { fontSize: 11, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: 2 },
  brand: { fontSize: 16, fontWeight: '700', color: '#000', marginTop: 3, letterSpacing: 0.5 },
});
