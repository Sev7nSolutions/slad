# Ślad – tracker tras na Androida 🐍

Startujesz trasę, a za Tobą rysuje się wężyk. Działa też przy zablokowanym ekranie.
Możesz zapisywać wiele tras, pokazać wszystkie naraz (każda w innym kolorze) i przeglądać statystyki.

## Jak zrobić plik APK (do wyboru)

### Sposób A – GitHub, bez komputera z Androidem
1. Załóż nowe repo na github.com i wrzuć do niego **całą zawartość tego folderu**
   (razem z ukrytym folderem `.github`).
2. Wejdź w zakładkę **Actions** → **Build APK** → **Run workflow**.
3. Po ok. 10–15 min na stronie buildu, na dole w **Artifacts**, pobierz `slad-apk`.
   To jest zip, a w środku jest `app-release.apk`.

### Sposób B – Expo EAS (potrzebny komputer z Node.js)
```bash
npm install
npx expo install --fix
npm install -g eas-cli
eas login            # darmowe konto na expo.dev
eas build -p android --profile preview
```
Na końcu dostaniesz link / kod QR do pobrania APK.

## Instalacja na telefonie
1. Wyślij APK na telefon z Androidem i otwórz plik.
2. Zezwól na **instalowanie z nieznanych źródeł**, gdy telefon o to zapyta.
3. Przy pierwszym starcie trasy ustaw lokalizację na **„Zezwalaj zawsze”**.
   Bez tego nie będzie nagrywać przy zablokowanym ekranie.
4. Zezwól też na powiadomienia. Podczas nagrywania widać powiadomienie „Ślad nagrywa trasę”.

**Tip:** na Xiaomi, Samsungu i Huawei wyłącz dla aplikacji „optymalizację baterii”.
Inaczej system może ubić nagrywanie w tle.

## Struktura
- `web/map.html` – cały wygląd: mapa, przyciski, lista tras. Po zmianach uruchom `npm run build:html`.
- `src/tracking.js` – GPS w tle (foreground service).
- `App.js` – łączy mapę z GPS i zapisuje trasy w pamięci telefonu.
